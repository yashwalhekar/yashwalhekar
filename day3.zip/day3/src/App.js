import logo from './logo.svg';
import './App.css';
import AppbarMui from './components/AppBarMui';
import CardsMui from './components/CardsMui';

function App() {
  return (
   <>
   <AppbarMui></AppbarMui>
   <CardsMui></CardsMui>
   </>
  );
}

export default App;
